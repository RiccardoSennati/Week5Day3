package it.riccardosennati.es2;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import it.riccardosennati.es2.beans.Stato;
import it.riccardosennati.es2.beans.Tavolo;

public class GestoreOrdini {
	
	private AnnotationConfigApplicationContext ctx;

	
	

}
