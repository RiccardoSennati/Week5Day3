package it.riccardosennati.es2.beans;

public enum StatoOrdine {

	INCORSO,
	PRONTO,
	SERVITO
}
