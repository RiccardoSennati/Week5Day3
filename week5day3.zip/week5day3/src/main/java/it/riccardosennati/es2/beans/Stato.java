package it.riccardosennati.es2.beans;

public enum Stato {

	OCCUPATO,
	LIBERO
}
